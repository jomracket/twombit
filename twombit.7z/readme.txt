TwoMbit is a cycle/bus accurate emulator for Sega's 8-bit game consoles
(Master System, Gamegear, SG-1000)

includes a cross-platform emulation library, so someone could build a gui without having to know the sms internals

notes:

- if you are using a mouse as input device, the cursor is hidden after activation. Press escape to show the cursor again.

- if you are using a bios keep in mind that the combination of game, bios and region matters like the real systems. So not all combinations are working.

- there are a few pal games which have glitches playing with us/jp region selected. These are no emulation bugs. It behaves the same at a real system.

- you can emulate a sms1 or sms2 unit. Like the real system, not all games run on both revisions correctly.

- combine cheats with savestates. There are cheats which seems to work like expected, but the memory location could used for someting other later on and game crashes. So deactivate cheats before such situations. Savestates saves time and frustration if you forget that or don't expect it. 

- if you want to use a window/fullscreen resolution not listed, please modify the config.ini

- most lcd monitor supports 60 Hz only. If you want to play a pal game with original scrolling, you should use a crt monitor. With a tool like powerstrip you can prepare a resolution for 50 Hz. But beware some crt models could be damaged permanently. So read manual and find out if 50 Hz is supported.

v 1.0.3
- [feature] added mac support
- [feature] added linux support
- [feature] added correct aspect switch
- [bugfix] scanlines in higher resolutions were displayed too thin
- [bugfix] better autodetection of pal games (the ones, which makes problems in a ntsc region).

v 1.0.2
- [feature] cheats
- [feature] savestates
- [bugfix] vscroll cache time
- [bugfix] sprite subsystem is processing during inactive display

v 1.0.1
[general]
- switched to gcc for compiler
- switched to QT 4.8 for Gui ( c# / .net is no more )
- build libsms (cross-plattform)

[emulation]
- gamegear emulation
- sg-1000 emulation
- emulating additional cart work ram (Ernie Els Golf, the castle, Othello)
- emulating bus contention
- emulating game gear bios
- emulating custom sram sizes (Shining force)
- emulating eeprom of the baseball series games
- emulating lightphaser, paddle (japanese and export), sportspad (japanese and export), 3d glasses, Terebi Oekaki
- emulating gear-2-gear at cycle level
	- parallel (Squinky Tennis in micro machines, Primal Rage, ...)
	- serial 
	- different baud rate settings
- emulating backward compatibillity of gamegear(mastergear) and sms
- emulating yamaha2413
- fex(zip, 7z, rar, gzip), bzip2, untar for compressed roms

[bugfixes]
- removed cache for irq detection, now irqs will be detected one cpu cycle before opcode edge ( simplified the overall process)
- fixed sample playback
- differentiate between sg and sms/gg vdp delay and access window behavior.

v 1.0.0
- sms emulation
- custom mappers: codemasters, korean, korean 8k
- .net WPF gui


to do:

feature doings
- replace directx to make TwoMbit platform independant

accuracy doings
- sn76489: writing to regs will not processed without delay
- vdp: accurate access windows during sprite processing
- vdp: split sprite subprocessing in timed steps (like bg processing) and not one sprite at a time
- yamaha2413: sub sample accuracy

